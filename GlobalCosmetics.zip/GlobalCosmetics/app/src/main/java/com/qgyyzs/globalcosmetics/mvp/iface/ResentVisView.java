package com.qgyyzs.globalcosmetics.mvp.iface;

import com.qgyyzs.globalcosmetics.base.IBaseView;
import com.qgyyzs.globalcosmetics.bean.VisitBean;

/**
 * Created by Administrator on 2017/12/15 0015.
 */

public interface ResentVisView extends IBaseView{
    void showResentVisResult(VisitBean bean);
}
