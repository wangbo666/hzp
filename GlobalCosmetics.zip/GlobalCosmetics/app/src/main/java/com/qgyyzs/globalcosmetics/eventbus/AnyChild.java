package com.qgyyzs.globalcosmetics.eventbus;

/**
 * Created by Administrator on 2017/12/19 0019.
 */

public class AnyChild {
}
