package com.qgyyzs.globalcosmetics.customview;

import android.widget.PopupWindow;

/**
 * Created by Administrator on 2017/3/28.
 */

public class MoreWindow extends PopupWindow {

}
