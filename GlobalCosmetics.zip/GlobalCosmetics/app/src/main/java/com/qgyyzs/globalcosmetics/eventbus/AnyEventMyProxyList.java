package com.qgyyzs.globalcosmetics.eventbus;

/**
 * Created by Administrator on 2017/8/14.
 */

public class AnyEventMyProxyList {
    public AnyEventMyProxyList(){}
}
