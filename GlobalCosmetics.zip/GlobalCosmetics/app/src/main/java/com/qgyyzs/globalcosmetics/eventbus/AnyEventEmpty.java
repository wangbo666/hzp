package com.qgyyzs.globalcosmetics.eventbus;

/**
 * Created by Administrator on 2017/9/25 0025.
 */

public class AnyEventEmpty {}
