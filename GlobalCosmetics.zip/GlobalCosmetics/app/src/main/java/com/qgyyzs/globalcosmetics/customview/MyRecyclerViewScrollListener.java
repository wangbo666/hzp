package com.qgyyzs.globalcosmetics.customview;

/**
 * Created by Administrator on 2017/12/19 0019.
 */

public class MyRecyclerViewScrollListener {
}
