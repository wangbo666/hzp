package com.qgyyzs.globalcosmetics.nim.about;

import android.widget.Button;

/**
 * Created by jezhee on 4/19/15.
 */
public class CustomActions {
    public static void customButton(Button button) {
        /// EMPTY NOW
    }
}
