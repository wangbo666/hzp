package com.qgyyzs.globalcosmetics.nim.config;

final class ServerEnvs {

    //
    // ENVs
    // DEFAULT Env.REL
    //

    static final ServerConfig.ServerEnv SERVER = ServerConfig.ServerEnv.REL;

}
