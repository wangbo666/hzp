package com.qgyyzs.globalcosmetics.mvp.iface;

import com.qgyyzs.globalcosmetics.base.IBaseView;
import com.qgyyzs.globalcosmetics.bean.ZizhiInfoBean;

/**
 * Created by admin on 2017/12/16.
 */

public interface ZizhiInfoView extends IBaseView{
    void showzizhiResult(ZizhiInfoBean bean);
}
